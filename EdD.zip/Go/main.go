// Para Instalar Go en UBUNTU es: sudo snap install go --classic

package main

func main() {
    print("Voy a Convertirme en un Gran Programador(o_o)!\n") // print Muestra en Panatlla el Mensaje que Está Entre Parentesis y Entre Comillas, \n es un Salto de Línea.
}

// Para Compilar el Código de Go es: go build -ldflags "-s -w" main.go
