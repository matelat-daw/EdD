// Para Instalar Rust en UBUNTU es: sudo apt install rustc

fn main() {
    println!("Voy a Convertirme en un Gran Programador(o_o)!");
}

// Para Compilar el Código Fuente es: rustc main.rs Para Ejecutarlo en Otros Ordenadores con el Mismo Sistema Operativo, o, rustc main.rs -C prefer-dynamic, Para que tenga un Tamaño de Archivo Acorde al Código Fuente, Aunque no Será Portable.
