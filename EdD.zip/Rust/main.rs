// Para Instalar Rust en UBUNTU es: sudo apt install rustc

fn main() {
    println!("Voy a Convertirme en un Gran Programador(o_o)!");
}

// Para Compilar el Código Fuente es: rustc main.rs
