// El Compilador de C++ en UBUNTU se Instala con: sudo apt install build-essential

#include <iostream> // Incluyo la Biblioteca Input Output Stream, que está en la ruta del compilador gpp.

int main() { // Todos los Programas en C++ de Consola Tienen la Función Principal int main()
    std::cout << "Voy a Convertirme en un Gran Programador(o_o)!\n"; // std::cout << Muestra en Pantalla el Texto que Está Entre Comillas, \n es un salto de línea.
    return 0; // Retorna 0, El programa ha funcionado Correctamente.
}

// Este Código Fuente se compila con: g++ -o main main.cpp
