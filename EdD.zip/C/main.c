// El Compilador de C en UBUNTU se Instala con: sudo apt install build-essential

#include <stdio.h> // Incluyo la Biblioteca estandar Input Output, que está en un archivo tipo h (header) en la ruta del compilador gcc.

int main() // Todos los Programas en C Tienen la Función Principal int main()
{
	printf ("Voy a Convertirme en un Gran Programador(o_o)!\n"); // Printf Muestra en Pantalla el Texto que Está Entre Parentesis y Entre Comillas, \n es un salto de línea.
}

// Este Código Fuente se compila con: gcc -o main main.c
