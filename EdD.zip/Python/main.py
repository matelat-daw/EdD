# Para Instalar Python en UBUNTU: sudo apt install python3

print("Voy a Convertirme en un Gran Programador(o_o)!") # Escribe en Pantalla lo que Está Entre Parentesis y Entre Comillas.

# Para Ver el resultado del Código Fuente se Usa: python3 main.py, Python es un lenguaje Interpretado.